# A-S 345
Web design code examples-learning html and css

0. unformatted text
1. adding comments and basic formatting
2. introduction to head and body
3. lists and tables
4. css and basic text formatting
5. adding images
6. div, span, and the box model
7. linking to pages and files
8. introduction to layout with css
9. css layout continued
10. floating content
11. introduction to bootstrap
12. screen sizes and responsive design
13. customizing bootstrap
